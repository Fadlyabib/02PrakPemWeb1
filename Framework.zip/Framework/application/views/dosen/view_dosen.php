<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Dosen</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Kelola Dosen</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4>Data Dosen</h4>
            <table class='table table-striped'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>NIDN</th>
                  <th>Nama</th>
                  <th>Gender</th>
                  <th>Tempat Lahir</th>
                  <th>Tanggal Lahir</th>
                  <th>Pendidikan</th>
                  <th>Program Studi</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $nomor = 1;
                foreach($list_dosen as $row){
                ?>
                <tr>
                  <td>
                    <?=$nomor?></td>
                  <td>
                    <?=$row->nidn;?>
                  </td>
                  <td>
                    <?=$row->nama;?>
                  </td>
                  <td>
                    <?=$row->gender;?>
                  </td>
                  <td>
                    <?=$row->tmp_lahir;?>
                  </td>
                  <td>
                    <?=$row->tgl_lahir;?>
                  </td>
                  <td>
                    <?=$row->pendidikan;?>
                  </td>
                  <td>
                    <?=$row->prodi_kode;?>
                  </td>
                  <td>
                    <a class="btn btn-info" href="dosen/view?id=<?=$row->nidn?>">view</a>
                    <a class="btn btn-warning" href="dosen/edit?id=<?=$row->nidn?>">Edit</a>
                    <a class="btn btn-danger" href="dosen/delete?id=<?=$row->nidn?>"
                    onclick="if(!confirm('Anda Yakin Hapus dosen NIM <?=$row->nidn?>?')) {return false}">Delete</a>
                  </td>
                </tr>
                <?php
                $nomor++;
                }
                ?>
              </tbody>
            </table>
            <a role="button" class="btn btn-primary" href="<?php echo base_url('index.php/dosen/create')?>">Create Dosen</a>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper --> 