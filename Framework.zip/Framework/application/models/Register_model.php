<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_model extends CI_Model {
    private $table = 'user';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        $this->db->where('username',$id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function save($data){
        // INSERT INTO user values (id,username,password,email,role,create_at,last_login)
        // insert into user values (default,'siswa2','12345','siswa2@sttnf.ac.id','MAHASISWA',default,default);
        $sql = "INSERT INTO user (id,username,password,email,role,created_at,last_login)
        VALUES (default,?,MD5(?),?,?,default,default)";
        $this->db->query($sql,$data);
    }
} 