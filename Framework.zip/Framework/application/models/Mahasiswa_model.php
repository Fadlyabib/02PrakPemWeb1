<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa_model extends CI_Model {
    // public $id;
    // public $nama;
    // public $nim;
    // public $gender;
    // public $tmp_lahir;
    // public $tgl_lahir;
    // public $ipk;
    // public $prodi;
    
    private $table = 'mahasiswa';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        $this->db->where('nim',$id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function save($data){
        // INSERT INTO mahasiswa (nim,nama,gender,tmp_lahir,tgl_lahir,ipk)
        // VALUES ('021312','ahmad','L','Jakarta','2000-05-04',3.40);
        $sql = "INSERT INTO mahasiswa (nim,nama,gender,tmp_lahir,tgl_lahir,prodi_kode,ipk)
        VALUES (?,?,?,?,?,?,?)";
        $this->db->query($sql,$data);
    }

    public function update($data){
        // UPDATE
        $sql = "UPDATE mahasiswa SET nim=?,nama=?,gender=?,tmp_lahir=?,
        tgl_lahir=?,prodi_kode=?,ipk=? WHERE nim=?";
        $this->db->query($sql,$data);
    }

     public function delete($id){
        // DELETE FROM mahasiswa WHERE nim=$id;
        $sql = "delete from mahasiswa where nim=?";
        $this->db->query($sql,array($id));
    }

    public function update_foto($array){
        $sql = "UPDATE mahasiswa SET foto=? WHERE nim=?";
        $this->db->query($sql, $array);
    }
        
    // public function predikat(){
    //     $predikat = ($this->ipk >= 3.75) ? "Cumlaude" : "Baik";
    //     return $this->predikat = $predikat;
    // } 
} 