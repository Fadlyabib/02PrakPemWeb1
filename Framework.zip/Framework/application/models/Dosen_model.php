<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen_model extends CI_Model {
    // public $id;
    // public $nama;
    // public $nidn;
    // public $gender;
    // public $tmp_lahir;
    // public $tgl_lahir;
    // public $prodi;
    // public $pendidikan;

    private $table = 'dosen';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        $this->db->where('nidn',$id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function save($data){
        // INSERT INTO dosen (nidn,nama,gender,tmp_lahir,tgl_lahir,pendidikan,prodi_kode)
        // INSERT INTO dosen values ('011022','Tifani','P','Jakarta’,'1999-03-08','S2','SI') 
        $sql = "INSERT INTO dosen (nidn,nama,gender,tmp_lahir,tgl_lahir,pendidikan,prodi_kode)
        VALUES (?,?,?,?,?,?,?)";
        $this->db->query($sql,$data);
    }

    public function update($data){
        // UPDATE
        $sql = "UPDATE dosen SET nidn=?,nama=?,gender=?,tmp_lahir=?,
        tgl_lahir=?,pendidikan=?,prodi_kode=? WHERE nidn=?";
        $this->db->query($sql,$data);
    }

    public function delete($id){
        // DELETE FROM dosen WHERE nidn=$id;
        $sql = "delete from dosen where nidn=?";
        $this->db->query($sql,array($id));
    }

    public function update_foto($array){
        $sql = "UPDATE dosen SET foto=? WHERE nidn=?";
        $this->db->query($sql, $array);
    }
} 