<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matkul_model extends CI_Model {
    public $id;
    public $nama;
    public $kode;
    public $sks;
}