<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
	public function index(){
        // $this->load->model('Dosen_model','dn1');
        // $this->dn1->id=1;
        // $this->dn1->nidn='012001';
        // $this->dn1->nama='Fikri Faiz';
        // $this->dn1->gender='L';
        // $this->dn1->prodi='Teknik Informatika';
        // $this->dn1->pendidikan='S1';

        // $this->load->model('Dosen_model','dn2');
        // $this->dn2->id=2;
        // $this->dn2->nidn='022001';
        // $this->dn2->nama='Wangi Pandan';
        // $this->dn2->gender='P';
        // $this->dn2->prodi='Sistem Informasi';
        // $this->dn2->pendidikan='S2';

        // $list_dn = [$this->dn1, $this->dn2];
        // $data['list_dn']=$list_dn;

        $this->load->model('dosen_model','dosen');
        $data['list_dosen']=$this->dosen->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('dosen/view_dosen',$data);
        $this->load->view('layout/footer');
	}

    public function view(){
        $_nidn = $this->input->get('id');
        $this->load->model('dosen_model','dosen');
        $data['dsn']=$this->dosen->findById($_nidn);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/view',$data);
        $this->load->view('layout/footer');
        //die("NIM ".$_nim);
    }

    public function create(){
        $data['judul']='Form Kelola Dosen';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('dosen/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("dosen_model","dosen");

        $_nidn = $this->input->post('nidn');
        $_nama= $this->input->post('nama');
        $_gender = $this->input->post('jk');
        $_tmp_lahir = $this->input->post('tmp_lahir');
        $_tgl_lahir = $this->input->post('tgl_lahir');
        $_pendidikan = $this->input->post('pendidikan');
        $_prodi = $this->input->post('prodi_kode');
        $_idedit = $this->input->post('idedit');//hidden field

        $data_dsn[]=$_nidn;// ? 1
        $data_dsn[]=$_nama;// ? 2
        $data_dsn[]=$_gender;// ? 3
        $data_dsn[]=$_tmp_lahir;// ? 4
        $data_dsn[]=$_tgl_lahir;// ? 5
        $data_dsn[]=$_pendidikan;// ? 6
        $data_dsn[]=$_prodi;// ? 7

        if(isset($_idedit)){
            //update data lama
            $data_dsn[]=$_idedit; // ? 8
            $this->dosen->update($data_dsn);
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->dosen->save($data_dsn);
        }
        
        redirect(base_url().'index.php/dosen/view?id='.$_nidn, 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("dosen_model","dosen");
        $dsnedit = $this->dosen->findById($_id);

        $data['judul']='Form Update Dosen';
        $data['dsnedit']=$dsnedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("dosen_model","dosen");
        $this->dosen->delete($_id);
        redirect(base_url().'index.php/dosen', 'refresh');
    }

    public function upload(){
        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 4096;
        $config['max_height']           = 3072;

        $_nidn = $this->input->post('nidn');

        $array = explode('.', $_FILES['fotodsn']['name']);
        $extension = end($array);

        $new_name = $_nidn.'.'.$extension;
        $config['file_name'] = $new_name;

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('fotodsn')){
            $error = array('error' => $this->upload->display_errors());
            die(print_r($error));
            $this->load->view('upload_form', $error);
        }else{
            $this->load->model("dosen_model","dosen");
            $array_data[] = $new_name;
            $array_data[] = $_nidn;
            $this->dosen->update_foto($array_data);
            $data = array('upload_data' => $this->upload->data());
            // $this->load->view('upload_success', $data);
        }
        redirect(base_url().'index.php/dosen/view?id='.$_nidn);
    }

    // public function save(){
    //     $this->load->model('Dosen_model','dsn');
    //     $this->dsn->nidn = $this->input->post('nidn');
    //     $this->dsn->nama = $this->input->post('nama');
    //     $this->dsn->jk = $this->input->post('jk');
    //     $this->dsn->tmp_lahir = $this->input->post('tmp_lahir');
    //     $this->dsn->tgl_lahir = $this->input->post('tgl_lahir');
    //     $this->dsn->pendidikan = $this->input->post('pendidikan');
    //     $this->dsn->prodi_kode = $this->input->post('prodi_kode');

    //     // die(print_r($this->dn1));
    //     $data['dsn']=$this->dsn;
    //     $this->load->view('layout/header');
    //     $this->load->view('layout/sidebar');
	// 	$this->load->view('dosen/view',$data);
    //     $this->load->view('layout/footer');
    // }
}