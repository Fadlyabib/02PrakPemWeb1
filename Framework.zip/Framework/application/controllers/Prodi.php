<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prodi extends CI_Controller {
    public function index(){
        $this->load->model('prodi_model','prodi');
        $list_prodi = $this->prodi->getAll();
        $data['list_prodi'] = $list_prodi;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('prodi/index',$data);
        $this->load->view('layout/footer');
    }

    public function view(){
        $_kode = $this->input->get('id');
        $this->load->model('prodi_model','prodi');
        $data['dsn']=$this->prodi->findById($_kode);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/view',$data);
        $this->load->view('layout/footer');
        //die("NIM ".$_nim);
    }

    public function create(){
        $data['judul']='Form Kelola Prodi';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("prodi_model","prodi");

        $_kode = $this->input->post('kode');
        $_nama= $this->input->post('nama');
        $_kaprodi = $this->input->post('kaprodi');
        $_idedit = $this->input->post('idedit');//hidden field

        $data_dsn[]=$_kode;// ? 1
        $data_dsn[]=$_nama;// ? 2
        $data_dsn[]=$_kaprodi;// ? 3

        if(isset($_idedit)){
            //update data lama
            $data_dsn[]=$_idedit; // ? 8
            $this->prodi->update($data_dsn);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->prodi->save($data_dsn);   
        }
        
        redirect(base_url().'index.php/prodi/view?id='.$_kode, 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("prodi_model","prodi");
        $dsnedit = $this->prodi->findById($_id);

        $data['judul']='Form Update Prodi';
        $data['dsnedit']=$dsnedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('prodi/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("prodi_model","prodi");
        $this->prodi->delete($_id);
        redirect(base_url().'index.php/prodi', 'refresh');
    }

    public function upload(){
        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 4096;
        $config['max_height']           = 3072;

        $_kode = $this->input->post('kode');

        $array = explode('.', $_FILES['fotodsn']['name']);
        $extension = end($array);

        $new_name = $_kode.'.'.$extension;
        $config['file_name'] = $new_name;

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('fotodsn')){
            $error = array('error' => $this->upload->display_errors());
            die(print_r($error));
            $this->load->view('upload_form', $error);
        }else{
            $this->load->model("prodi_model","prodi");
            $array_data[] = $new_name;
            $array_data[] = $_kode;
            $this->prodi->update_foto($array_data);
            $data = array('upload_data' => $this->upload->data());
            // $this->load->view('upload_success', $data);
        }
        redirect(base_url().'index.php/prodi/view?id='.$_kode);
    }
}