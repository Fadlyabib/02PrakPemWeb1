<table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th>1</th>
            <th>Muhammad Affan</th>
        </tr>
    </tbody>
</table>