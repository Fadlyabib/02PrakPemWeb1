<?php 
include_once('header.php');
include_once('sidebar.php');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Array buah</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="prak01.php">Praktikum 01</a></li>
            <li class="breadcrumb-item active">Array buah</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php
            //deklarasi array
            $array_buah = ['Pisang', 'Jeruk', 'Apel', 'Mangga'];

            //menampilkan array
            echo 'Menampilkan data array 0 => '.$array_buah[0].'<br>';

            //menampilkan jumlah array
            echo 'Menampilkan jumlah data array => '.count($array_buah).'<br>';

            echo '<hr>';
            //Menampilkan array dengan foreach
            foreach ($array_buah as $key => $value) {
                echo 'Menambahkan data array ke-'.$key.' => '.$value.'<br>';
            }
            echo '<hr>';

            //Menampilkan array dengan list
            echo '<ol>';
            foreach ($array_buah as $value) {
                echo '<li>'.$value.'</li>';
            }
            echo '</ol>';
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php include_once('footer.php'); ?>