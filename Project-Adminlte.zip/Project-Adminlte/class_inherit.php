<?php 
include_once 'header.php';
include_once 'sidebar.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Class Inheretance</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="prak05.php">Praktikum 05</a></li>
              <li class="breadcrumb-item active">Class Inheretance</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php
            class Fruit {
                public $name;
                public $color;

                public function __construct($name, $color){
                    $this->name = $name;
                    $this->color = $color;
                }
                public function intro(){
                    echo "The fruit is $this->name and the color is $this->color.";
                }
            }
            class Strawberry extends Fruit {
                public function message(){
                    echo "Am I a fruit or a berry? <br/>";
                }
            }
            $strawberry = new Strawberry("Strawberry", "red");
            $strawberry->message();
            $strawberry->intro();
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>