<?php 
include_once('header.php');
include_once('sidebar.php');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Array push</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="prak01.php">Praktikum 01</a></li>
            <li class="breadcrumb-item active">Array push</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php 
            $tims = ['erwin','heru','ali','zaki'];
            array_push($tims,'wati');
            foreach ($tims as $value) {
                echo $value.'<br>';
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php include_once('footer.php'); ?>