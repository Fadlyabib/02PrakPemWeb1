<?php
include_once('atas_bootstrap.php');
require_once('body_bootstrap.php');
include_once('bawah_bootstrap.php');
?>