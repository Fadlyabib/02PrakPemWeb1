<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Class Dispenser</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="prak05.php">Praktikum 05</a></li>
              <li class="breadcrumb-item active">Class Dispenser</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php
            class Dispenser{
                public $volume;
                public $hargaSegelas;
                public $volumeGelas;
                public $namaMinuman;
    
                function isi($vol, $harga, $volume, $nama){
                    $this->volume = $vol;
                    $this->hargaSegelas = $harga;
                    $this->volumeGelas = $volume;
                    $this->namaMinuman = $nama;

                    echo "Sebuah Dispenser berisi $this->volume ml bernama $this->namaMinuman, harga setiap gelas Rp$this->hargaSegelas berisi $this->volumeGelas ml.";
                }
            }
            $bisnis = new Dispenser();
            $bisnis->isi(250, 1000, 10, 'segarrr');
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>