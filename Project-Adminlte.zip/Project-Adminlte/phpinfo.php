<?php 
    phpinfo();
?>