<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>ATM</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="prak05.php">Praktikum 05</a></li>
              <li class="breadcrumb-item active">ATM</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php
            require_once "class_account.php";
            require_once "class_accountbank.php";

            // $ac1 = new Account("020201", 5000000);
            // $ac2 = new Account("010102", 4500000);

            // $ac1->cetak();
            // $ac1->deposit(75000);
            // echo "<br/>Nabung 75000<br/>";
            // $ac1->cetak();
            // echo '<hr>';

            $ab1 = new AccountBank('C001', 'Ahmad', 6000000);
            $ab2 = new AccountBank('C002', 'Budi', 5350000);
            $ab3 = new AccountBank('C003', 'Kurniawan', 2500000);

            //sebelum function
            $ab1->cetak();
            echo "<hr>";
            $ab2->cetak();
            echo "<hr>";
            $ab3->cetak();
            echo "<hr>";

            // echo '<br/>Ahmad nabung 1.000.000';
            $ab1->deposit(1000000);
            // echo '<br/>Ahmad transfer 1.500.000 ke Kurniawan dan 500.000 ke Budi';
            $ab1->transfer($ab3, 1500000);
            $ab1->transfer($ab2, 500000);
            // echo '<br/>Budi tarik uang 2.500.000';
            $ab2->tarik_uang($ab2, 2500000); 

            //sesudah function
            $ab1->cetak();
            echo "<hr>";
            $ab2->cetak();
            echo "<hr>";
            $ab3->cetak();
            echo "<hr>";
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>