<?php
class Pasien{
    public $tanggal;
    public $kode;
    public $nama;
    public $gender;

    function __construct($tanggal, $kode, $nama, $gender){
        $this->tanggal = $tanggal;
        $this->kode = $kode;
        $this->nama = $nama;
        $this->gender = $gender;
    }
}
?>