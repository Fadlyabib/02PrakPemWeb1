<?php 
include_once 'header.php';
include_once 'sidebar.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Data Lingkaran</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="prak04.php">Praktikum 04</a></li>
              <li class="breadcrumb-item active">Data Lingkaran</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <?php
            require_once "class_lingkaran.php";

            echo "NILAI PHI: ".Lingkaran::PHI."<br/>";
            $lingkar1 = new Lingkaran( 10 );
            $lingkar2 = new Lingkaran( 4 );

            echo "Luas Lingkaran 1: ".$lingkar1->getLuas()."<br/>";
            echo "Luas Lingkaran 2: ".$lingkar2->getLuas()."<br/>";
            echo "<hr/>";
            echo "Keliling Lingkaran 1: ".$lingkar1->getKeliling()."<br/>";
            echo "Keliling Lingkaran 2: ".$lingkar2->getKeliling()."<br/>";
            ?>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div><!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>