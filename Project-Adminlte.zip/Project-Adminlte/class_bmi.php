<?php
require_once "class_pasien.php";

class Bmi extends Pasien{
    public $berat;
    public $tinggi;
    // public $nilai;

    function __construct($tanggal, $kode, $nama, $gender, $berat, $tinggi){
        parent::__construct($tanggal, $kode, $nama, $gender);
        $this->berat = $berat;
        $this->tinggi = $tinggi;
        // $this->nilai = $nilai;
    }

    public function nilai(){
        return $this->nilai = $this->berat / (($this->tinggi/100) * ($this->tinggi/100));
    }

    public function hasil(){
        if($this->nilai <= 18.5){
            return 'Kekurangan Berat Badan';
        }elseif($this->nilai <= 22.9){
            return 'Normal (Ideal)';
        }elseif($this->nilai <= 24.9){
            return 'Kelebihan Berat Badan';
        }elseif($this->nilai <= 29.9){
            return 'Kegemukan (Obesitas 1)';
        }elseif($this->nilai >= 30){
            return 'Kegemukan (Obesitas 2)';
        }
    }

    public function gambar(){
        if($this->nilai <= 18.5){
            echo "BMI anda adalah "."<b style='color: blue'>".round(($this->nilai),1)."</b>"."<br>"."<img src='imge/tipe1.png'/>"."<br>"."<br>"."<img src='imge/tipe1.1.png'>";
        }elseif($this->nilai <= 22.9){
            echo "BMI anda adalah "."<b style='color: blue'>".round(($this->nilai),1)."</b>"."<br>"."<img src='imge/tipe2.png'/>"."<br>"."<br>"."<img src='imge/tipe2.1.png'>";
        }elseif($this->nilai <= 24.9){
            echo "BMI anda adalah "."<b style='color: blue'>".round(($this->nilai),1)."</b>"."<br>"."<img src='imge/tipe3.png'/>"."<br>"."<br>"."<img src='imge/tipe3.1.png'>";
        }elseif($this->nilai <= 29.9){
            echo "BMI anda adalah "."<b style='color: blue'>".round(($this->nilai),1)."</b>"."<br>"."<img src='imge/tipe4.png'/>"."<br>"."<br>"."<img src='imge/tipe4.1.png'>";
        }elseif($this->nilai >= 30){
            echo "BMI anda adalah "."<b style='color: blue'>".round(($this->nilai),1)."</b>"."<br>"."<img src='imge/tipe5.png'/>"."<br>"."<br>"."<img src='imge/tipe5.1.png'>";
        }
    }
}
?>