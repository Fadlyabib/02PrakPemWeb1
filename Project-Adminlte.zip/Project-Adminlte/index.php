<?php 
include_once 'header.php';
include_once 'sidebar.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Home</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Home</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <a href="prak01.php">Pertemuan 01</a><br>
            <a href="prak02.php">Pertemuan 02</a><br>
            <a href="prak03.php">Pertemuan 03</a><br>
            <a href="prak04.php">Pertemuan 04</a><br>
            <a href="prak05.php">Pertemuan 05</a><br>
            <a href="prak06.php">Project</a><br>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php
include_once 'footer.php';
?>