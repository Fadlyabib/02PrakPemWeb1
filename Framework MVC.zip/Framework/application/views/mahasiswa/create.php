<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Praktikum 08 - Form Processing</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Praktikum 08</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-md-8">
                <h3>Form Kelola Mahasiswa</h3>
                <?php echo form_open('mahasiswa/save')?>
                <div class="form-group row">
                  <label for="nim" class="col-4 col-form-label">NIM</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-book"></i>
                        </div>
                      </div>
                      <input id="nim" name="nim" placeholder="NIM" type="number" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="nama" class="col-4 col-form-label">Nama</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-card"></i>
                        </div>
                      </div>
                      <input id="nama" name="nama" placeholder="Nama" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="gender" class="col-4 col-form-label">Gender</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-500px"></i>
                        </div>
                      </div>
                      <input id="gender" name="gender" placeholder="Gender" type="text" class="form-control"
                        required="required">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-home"></i>
                        </div>
                      </div>
                      <input id="tmp_lahir" name="tmp_lahir" placeholder="Tempat Lahir" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-calendar"></i>
                        </div>
                      </div>
                      <input id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir" type="date" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="prodi" class="col-4 col-form-label">Program Studi</label>
                  <div class="col-8">
                    <select id="prodi" name="prodi" class="custom-select" required="required">
                      <option value="Teknik Informatika">Teknik Informatika</option>
                      <option value="SIstema Informasi">SIstema Informasi</option>
                      <option value="Bisnis Digital">Bisnis Digital</option>
                    </select>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="ipk" class="col-4 col-form-label">IPK</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-bar-chart"></i>
                        </div>
                      </div>
                      <input id="ipk" name="ipk" placeholder="IPK" type="number" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="offset-4 col-8">
                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
                <?php echo form_close()?>
              </div>
              <div class="col-md-4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->