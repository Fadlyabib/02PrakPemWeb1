<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Praktikum 07 - Mahasiswa</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Praktikum 07</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            Data Mahasiswa
            <table border='1'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>NIM</th>
                  <th>Nama</th>
                  <th>Gender</th>
                  <th>Prodi</th>
                  <th>IPK</th>
                  <th>Predikat</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($list_mhs as $row){?>
                <tr>
                  <td>
                    <?=$row->id;?>
                  </td>
                  <td>
                    <?=$row->nim;?>
                  </td>
                  <td>
                    <?=$row->nama;?>
                  </td>
                  <td>
                    <?=$row->gender;?>
                  </td>
                  <td>
                    <?=$row->prodi;?>
                  </td>
                  <td>
                    <?=$row->ipk;?>
                  </td>
                  <td>
                    <?=$row->predikat();}?>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->