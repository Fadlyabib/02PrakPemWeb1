<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Home</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active">Home</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            <b>Pertemuan 07</b><br>
            <a href="<?php echo base_url('index.php/mahasiswa')?>">Mahasiswa</a><br>
            <a href="<?php echo base_url('index.php/dosen')?>">Dosen</a><br>
            <a href="<?php echo base_url('index.php/matkul')?>">Mata Kuliah</a><br>
            <br><b>Pertemuan 08</b><br>
            <a href="<?php echo base_url('index.php/mahasiswa/create')?>">Mahasiswa</a><br>
            <a href="<?php echo base_url('index.php/dosen/create')?>">Dosen</a><br>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->