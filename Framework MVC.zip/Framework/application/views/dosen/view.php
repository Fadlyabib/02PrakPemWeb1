<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Praktikum 08 - Form Kelola Dosen</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/mahasiswa/create')?>">Home</a></li>
            <li class="breadcrumb-item active">Praktikum 08</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 border border-dark">
        <div class="row mb-2">
          <div class="col-sm-12">
            Data Dosen
            <table border='1'>
              <thead>
                <tr>
                  <th>NIDN</th>
                  <th>Nama</th>
                  <th>Gender</th>
                  <th>Prodi</th>
                  <th>Pendidikan</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <?=$dn1->nidn;?>
                  </td>
                  <td>
                    <?=$dn1->nama;?>
                  </td>
                  <td>
                    <?=$dn1->gender;?>
                  </td>
                  <td>
                    <?=$dn1->prodi;?>
                  </td>
                  <td>
                    <?=$dn1->pendidikan;?>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->