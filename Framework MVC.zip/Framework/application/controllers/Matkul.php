<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matkul extends CI_Controller {
	public function index(){
        $this->load->model('Matkul_model','mk1');
        $this->mk1->id=1;
        $this->mk1->kode='BD01';
        $this->mk1->nama='Basis Data';
        $this->mk1->sks='3';

        $this->load->model('Matkul_model','mk2');
        $this->mk2->id=2;
        $this->mk2->kode='PW02';
        $this->mk2->nama='Pemrograman Web';
        $this->mk2->sks='3';

        $list_mk = [$this->mk1, $this->mk2];
        $data['list_mk']=$list_mk;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('matkul/view_matkul',$data);
        $this->load->view('layout/footer');
	}
}