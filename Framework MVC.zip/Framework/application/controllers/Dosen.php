<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
	public function index(){
        $this->load->model('Dosen_model','dn1');
        $this->dn1->id=1;
        $this->dn1->nidn='012001';
        $this->dn1->nama='Fikri Faiz';
        $this->dn1->gender='L';
        $this->dn1->prodi='Teknik Informatika';
        $this->dn1->pendidikan='S1';

        $this->load->model('Dosen_model','dn2');
        $this->dn2->id=2;
        $this->dn2->nidn='022001';
        $this->dn2->nama='Wangi Pandan';
        $this->dn2->gender='P';
        $this->dn2->prodi='Sistem Informasi';
        $this->dn2->pendidikan='S2';

        $list_dn = [$this->dn1, $this->dn2];
        $data['list_dn']=$list_dn;

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('dosen/view_dosen',$data);
        $this->load->view('layout/footer');
	}

    public function create(){
        $data['judul']='Form Kelola Dosen';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('dosen/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model('Dosen_model','dn1');
        $this->dn1->nidn = $this->input->post('nidn');
        $this->dn1->nama = $this->input->post('nama');
        $this->dn1->gender = $this->input->post('gender');
        $this->dn1->tmp_lahir = $this->input->post('tmp_lahir');
        $this->dn1->tgl_lahir = $this->input->post('tgl_lahir');
        $this->dn1->prodi = $this->input->post('prodi');
        $this->dn1->pendidikan = $this->input->post('pendidikan');

        // die(print_r($this->dn1));
        $data['dn1']=$this->dn1;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('dosen/view',$data);
        $this->load->view('layout/footer');
    }
}