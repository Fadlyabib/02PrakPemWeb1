<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Cobakegiatan_model extends CI_Model {
    private $table = 'kegiatan';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }
    public function findById($id){
        $this->db->where('id',$id);
        $query = $this->db->get($this->table); 
        return $query->row();
    }
    public function getById($id){
        $this->db->where('judul',$id);
        $query = $this->db->get($this->table); 
        return $query->row();
    }
    public function save($data){
        // INSERT INTO kegiatan (judul,kapasitas,harga_tiket,tanggal,narasumber,pic)
        // VALUES ('021312','ahmad','L','Jakarta','2000-05-04',3.40);
        $sql = "INSERT INTO kegiatan (judul,kapasitas,harga_tiket,tanggal,narasumber,tempat,pic,jenis_id)
        VALUES (?,?,?,?,?,?,?,?)";
        $this->db->query($sql,$data);
    }
    public function update($data){
        // UPDATE
        $sql = "UPDATE kegiatan SET judul=?,kapasitas=?,harga_tiket=?,tanggal=?,
        narasumber=?,tempat=?,pic=?,jenis_id=? WHERE id=?";
        $this->db->query($sql,$data);
    }
     public function delete($id){
        // DELETE FROM kegiatan WHERE judul=$id;
        $sql = "delete from kegiatan where id=?";
        $this->db->query($sql,array($id));
    }
    public function update_foto_flyer($array){
        $sql = "UPDATE kegiatan SET foto_flyer=? WHERE id=?";
        $this->db->query($sql, $array);
    }
} 