<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class users_model extends CI_Model {
    private $table = 'users';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }
    public function findById($id){
        $this->db->where('id',$id);
        $query = $this->db->get($this->table); 
        return $query->row();
    }
    public function getById($id){
        $this->db->where('username',$id);
        $query = $this->db->get($this->table); 
        return $query->row();
    }
    public function save($data){
        $sql = "INSERT INTO users (username, password, email, role)
        VALUES (?,md5(?),?,?)";
        $this->db->query($sql,$data);
    }
    public function update($data){
        $sql = "UPDATE users SET username=?, password=?, email=?, role=? WHERE id=?";
        $this->db->query($sql,$data);
    }
     public function delete($id){
        $sql = "delete from users where id=?";
        $this->db->query($sql,array($id));
    }
} 
?>