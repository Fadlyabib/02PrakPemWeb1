<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cobadaftar_model extends CI_Model {
    private $table = 'daftar';
    public function getAll(){
        $query = $this->db->get($this->table);
        return $query->result();
    }
    public function findById($id){
        $this->db->where('tanggal_daftar',$id);
        $query = $this->db->get($this->table); 
        return $query->row();
    }
    public function save($data){
        // INSERT INTO daftar (tanggal_daftar,alasan,users_id,kegiatan_id,kategori_peserta_id,nosertifikat)
        // VALUES ('021312','ahmad','L','Jakarta','2000-05-04',3.40);
        $sql = "INSERT INTO daftar (tanggal_daftar,alasan,users_id,kegiatan_id,kategori_peserta_id,nosertifikat)
        VALUES (?,?,?,?,?,?)";
        $this->db->query($sql,$data);
    }
    public function update($data){
        // UPDATE
        $sql = "UPDATE daftar SET tanggal_daftar=?,alasan=?,users_id=?,kegiatan_id=?,
        kategori_peserta_id=?,nosertifikat=? WHERE tanggal_daftar=?";
        $this->db->query($sql,$data);
    }
     public function delete($id){
        // DELETE FROM daftar WHERE tanggal_daftar=$id;
        $sql = "delete from daftar where tanggal_daftar=?";
        $this->db->query($sql,array($id));
    }
    public function update_foto_flyer($array){
        $sql = "UPDATE daftar SET foto_flyer=? WHERE tanggal_daftar=?";
        $this->db->query($sql, $array);
    }
} 