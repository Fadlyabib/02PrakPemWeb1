<?php
defined('BASEPATH') OR exit('No direct script access allowed');  

class kategoripeserta extends CI_Controller {
	public function index(){
        $this->load->model('kategoripeserta_model','kategoripeserta');
        $data['list_kategoripeserta']=$this->kategoripeserta->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('kategoripeserta/view_kategoripeserta',$data);
        $this->load->view('layout/footer');
	}

    public function view(){
        $_id = $this->input->get('id');
        $this->load->model('kategoripeserta_model','kategoripeserta');
        $data['kp']=$this->kategoripeserta->findById($_id);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('kategoripeserta/view',$data);
        $this->load->view('layout/footer');
    }

    public function create(){
        $this->load->model('all_model','all');

        $data['judul']='Form Kelola Kategori Peserta';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('kategoripeserta/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("kategoripeserta_model","kategoripeserta");

        $_nama = $this->input->post('nama');
        $_idedit = $this->input->post('idedit');

        $data_kp[]=$_nama;

        if(isset($_idedit)){

            $data_kp[]=$_idedit;
            $this->kategoripeserta->update($data_kp);  
        }else{ 
            $this->kategoripeserta->save($data_kp);
        }
        
        redirect(base_url().'index.php/kategoripeserta', 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("kategoripeserta_model","kategoripeserta");
        $kpedit = $this->kategoripeserta->findById($_id);

        $this->load->model('all_model','all');
		
        $data['judul']='Form Update Kategori Peserta';
        $data['kpedit']=$kpedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('kategoripeserta/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("kategoripeserta_model","kategoripeserta");
        $this->kategoripeserta->delete($_id);
        redirect(base_url().'index.php/kategoripeserta', 'refresh');
    }
} 
?>