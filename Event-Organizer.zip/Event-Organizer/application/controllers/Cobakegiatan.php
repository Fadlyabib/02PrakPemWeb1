<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Cobakegiatan extends CI_Controller {
	public function index(){
        $this->load->model('cobakegiatan_model','cobakegiatan');
        $data['list_cobakegiatan']=$this->cobakegiatan->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('cobakegiatan/view_cobakegiatan',$data);
        $this->load->view('layout/footer');
	}

    // public function viewasave(){
    //     // $_id = $this->input->get('id');
    //     $_judul = $this->input->get('id');
    //     $this->load->model('cobakegiatan_model','cobakegiatan');
    //     // $data['ck']=$this->cobakegiatan->findById($_id);
    //     $data['ck']=$this->cobakegiatan->getById($_judul);

    //     $this->load->view('layout/header'); 
    //     $this->load->view('layout/sidebar');
    //     $this->load->view('cobakegiatan/viewsave',$data);
    //     $this->load->view('layout/footer');
    //     //die("judul ".$_judul);
    // }

    public function view(){
        $_id = $this->input->get('id');
        // $_judul = $this->input->get('id');
        $this->load->model('cobakegiatan_model','cobakegiatan');
        $data['ck']=$this->cobakegiatan->findById($_id);
        // $data['ck']=$this->cobakegiatan->getById($_judul);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobakegiatan/view',$data);
        $this->load->view('layout/footer');
        //die("judul ".$_judul);
    }

    public function create(){
        $this->load->model('all_model','all');
		$data['list_jenis_kegiatan'] = $this->all->getAll('jenis_kegiatan');

        $data['judul']='Form Kelola Kegiatan';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobakegiatan/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("cobakegiatan_model","cobakegiatan");
        // $_id = $this->input->get('id');
        // $data['ck']=$this->cobakegiatan->findById($_id);

        $_judul = $this->input->post('judul');
        $_kapasitas= $this->input->post('kapasitas');
        $_harga_tiket = $this->input->post('harga_tiket');
        $_tanggal = $this->input->post('tanggal');
        $_narasumber = $this->input->post('narasumber');
        $_tempat = $this->input->post('tempat');
        $_pic = $this->input->post('pic');
        $_jenis_id = $this->input->post('jenis_id');
        $_idedit = $this->input->post('idedit');//hidden field

        // $data_ck[]=$_id;
        $data_ck[]=$_judul;// ? 1
        $data_ck[]=$_kapasitas;// ? 2 
        $data_ck[]=$_harga_tiket;// ? 3
        $data_ck[]=$_tanggal;// ? 4
        $data_ck[]=$_narasumber;// ? 5
        $data_ck[]=$_tempat; // ? 6
        $data_ck[]=$_pic;// ? 7
        $data_ck[]=$_jenis_id; // ? 8

        if(isset($_idedit)){
            //update data lama
            $data_ck[]=$_idedit; // ? 
            $this->cobakegiatan->update($data_ck);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->cobakegiatan->save($data_ck);
        }
        
        redirect(base_url().'index.php/cobakegiatan', 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("cobakegiatan_model","cobakegiatan");
        $ckedit = $this->cobakegiatan->findById($_id);

        $this->load->model('all_model','all');
		$data['list_jenis_kegiatan'] = $this->all->getAll('jenis_kegiatan');

        $data['judul']='Form Update Kegiatan';
        $data['ckedit']=$ckedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobakegiatan/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("cobakegiatan_model","cobakegiatan");
        $this->cobakegiatan->delete($_id);
        redirect(base_url().'index.php/cobakegiatan', 'refresh');
    }

    public function upload(){
        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 4096;
        $config['max_height']           = 3072;

        $_id = $this->input->post('id');

        $array = explode('.', $_FILES['foto_flyerck']['name']);
        $extension = end($array);

        $new_name = $_id.'.'.$extension;
        $config['file_name'] = $new_name;

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('foto_flyerck')){
            $error = array('error' => $this->upload->display_errors()); 
            die(print_r($error));
            $this->load->view('upload_form', $error);
        }else{
            $this->load->model("cobakegiatan_model","cobakegiatan");
            $array_data[] = $new_name;
            $array_data[] = $_id;
            $this->cobakegiatan->update_foto_flyer($array_data);
            $data = array('upload_data' => $this->upload->data());
            // $this->load->view('upload_success', $data);
        }
        redirect(base_url().'index.php/cobakegiatan/view?id='.$_id);
    }

    //     // die(print_r($this->ck1));
    //     $data['ck1']=$this->ck1;
    //     $this->load->view('layout/header');
    //     $this->load->view('layout/sidebar');
	// 	$this->load->view('cobakegiatan/view',$data);
    //     $this->load->view('layout/footer');
    // } 
} 