<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function index(){
        $data = [];
        $this->load->view('login',$data);
    }

    public function otentikasi(){
        $this->load->model("user_model","users");
        $_username = $this->input->post('username');
        $_password = $this->input->post('password');

        $row = $this->users->login($_username,$_password);
        if(isset($row)){// jika user terdaftar di database
            $this->session->set_userdata('username',$row->username);
            $this->session->set_userdata('role',$row->role);
            $this->session->set_userdata('users',$row);
            redirect(base_url().'index.php/homelogin');
        }else{// jika user tidak (username password salah)
            redirect(base_url().'index.php/login?status=f');
        }
    }

    public function logout(){
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('role');
        $this->session->unset_userdata('users');
        redirect(base_url().'index.php/home');
    }
} 