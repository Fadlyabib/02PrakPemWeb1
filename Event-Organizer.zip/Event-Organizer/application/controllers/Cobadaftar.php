<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Cobadaftar extends CI_Controller {
	public function index(){
        $this->load->model('cobadaftar_model','cobadaftar');
        $data['list_cobadaftar']=$this->cobadaftar->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('cobadaftar/view_cobadaftar',$data);
        $this->load->view('layout/footer');
	}

    public function view(){
        $_tanggal_daftar = $this->input->get('id');
        $this->load->model('cobadaftar_model','cobadaftar'); 
        $data['cd']=$this->cobadaftar->findById($_tanggal_daftar);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobadaftar/view',$data);
        $this->load->view('layout/footer');
        //die("tanggal_daftar ".$_tanggal_daftar);
    }

    public function create(){
        $this->load->model('all_model','all');
		$data['list_users'] = $this->all->getAll('users');
		$data['list_kegiatan'] = $this->all->getAll('kegiatan');
		$data['list_kategori_peserta'] = $this->all->getAll('kategori_peserta'); 

        $data['judul']='Form Kelola Daftar';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobadaftar/create',$data);
        $this->load->view('layout/footer');
    }

    public function session(){
        
    }

    public function save(){
        $this->load->model("cobadaftar_model","cobadaftar");

        $_tanggal_daftar = $this->input->post('tanggal_daftar');
        $_alasan= $this->input->post('alasan');
        $_users_id = $this->input->post('users_id');
        $_kegiatan_id = $this->input->post('kegiatan_id');
        $_kategori_peserta_id = $this->input->post('kategori_peserta_id');
        $_nosertifikat = $this->input->post('nosertifikat');
        $_idedit = $this->input->post('idedit');//hidden field

        $data_cd[]=$_tanggal_daftar;// ? 1
        $data_cd[]=$_alasan;// ? 2 
        $data_cd[]=$_users_id;// ? 3
        $data_cd[]=$_kegiatan_id;// ? 4
        $data_cd[]=$_kategori_peserta_id;// ? 5
        $data_cd[]=$_nosertifikat;// ? 6

        if(isset($_idedit)){
            //update data lama
            $data_cd[]=$_idedit; // ? 8
            $this->cobadaftar->update($data_cd);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->cobadaftar->save($data_cd);
        }
        redirect(base_url().'index.php/cobadaftar', 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("cobadaftar_model","cobadaftar");
        $cdedit = $this->cobadaftar->findById($_id);

        $this->load->model('all_model','all');
		$data['list_users'] = $this->all->getAll('users');
		$data['list_kegiatan'] = $this->all->getAll('kegiatan');
		$data['list_kategori_peserta'] = $this->all->getAll('kategori_peserta'); 

        $data['judul']='Form Update Daftar';
        $data['cdedit']=$cdedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobadaftar/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("cobadaftar_model","cobadaftar");
        $this->cobadaftar->delete($_id);
        redirect(base_url().'index.php/cobadaftar', 'refresh');
    }

    public function upload(){
        $config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 4096;
        $config['max_height']           = 3072;

        $_tanggal_daftar = $this->input->post('tanggal_daftar');

        $array = explode('.', $_FILES['foto_flyercd']['name']);
        $extension = end($array);

        $new_name = $_tanggal_daftar.'.'.$extension;
        $config['file_name'] = $new_name;

        $this->load->library('upload', $config);

        if( ! $this->upload->do_upload('foto_flyercd')){
            $error = array('error' => $this->upload->display_errors());
            die(print_r($error));
            $this->load->view('upload_form', $error);
        }else{
            $this->load->model("cobadaftar_model","cobadaftar");
            $array_data[] = $new_name;
            $array_data[] = $_tanggal_daftar;
            $this->cobadaftar->update_foto_flyer($array_data);
            $data = array('upload_data' => $this->upload->data());
            // $this->load->view('upload_success', $data);
        }
        redirect(base_url().'index.php/cobadaftar/view?id='.$_tanggal_daftar);
    }

    

    //     // die(print_r($this->cd1));
    //     $data['cd1']=$this->cd1;
    //     $this->load->view('layout/header');
    //     $this->load->view('layout/sidebar');
	// 	$this->load->view('cobadaftar/view',$data);
    //     $this->load->view('layout/footer');
    // } 
} 