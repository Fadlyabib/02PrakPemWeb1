<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
    public function index(){
        $this->load->model('register_model','register');
        $data['list_register']=$this->register->getAll();

		$this->load->view('register/view_register',$data);
	}

    public function save(){
        $this->load->model("register_model","register");

        $_username = $this->input->post('username');
        $_password = $this->input->post('password');
        $_email = $this->input->post('email');
        $_role = $this->input->post('role');
        $_idedit = $this->input->post('idedit');//hidden field 

        $data_rgr[]=$_username;// ? 1
        $data_rgr[]=$_password;// ? 2
        $data_rgr[]=$_email;// ? 3
        $data_rgr[]=$_role;// ? 4

        if(isset($_idedit)){
            //update data lama
            $data_rgr[]=$_idedit; // ? 8
            $this->register->update($data_rgr);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->register->save($data_rgr);   
        }
        
        redirect(base_url().'index.php/login?id='.$_username, 'refresh');
    }
} 