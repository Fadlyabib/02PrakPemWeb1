<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class users extends CI_Controller {
	public function index(){
        $this->load->model('users_model','users');
        $data['list_users']=$this->users->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('users/view_users',$data);
        $this->load->view('layout/footer');
	}
    public function view(){
        $_id = $this->input->get('id');
        $this->load->model('users_model','users');
        $data['us']=$this->users->findById($_id);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('users/view',$data);
        $this->load->view('layout/footer');
    }
    public function create(){
        $this->load->model('all_model','all');

        $data['judul']='Form Kelola Users';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('users/create',$data);
        $this->load->view('layout/footer');
    }
    public function save(){
        $this->load->model("users_model","users");

        $_username = $this->input->post('username');
        $_password = $this->input->post('password');
        $_email = $this->input->post('email');
        $_role = $this->input->post('role');
        $_idedit = $this->input->post('idedit');

        $data_us[]=$_username;
        $data_us[]=$_password;
        $data_us[]=$_email;
        $data_us[]=$_role;

        if(isset($_idedit)){
            $data_us[]=$_idedit;
            $this->users->update($data_us);  
        }else{ 
            $this->users->save($data_us);
        }
        redirect(base_url().'index.php/users', 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("users_model","users");
        $usedit = $this->users->findById($_id);

        $this->load->model('all_model','all');

        $data['judul']='Form Update users';
        $data['usedit']=$usedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('users/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("users_model","users");
        $this->users->delete($_id);
        redirect(base_url().'index.php/users', 'refresh');
    }
} 
?>