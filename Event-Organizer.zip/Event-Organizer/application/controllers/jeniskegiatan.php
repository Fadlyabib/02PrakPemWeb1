<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class jeniskegiatan extends CI_Controller {
	public function index(){
        $this->load->model('jeniskegiatan_model','jeniskegiatan');
        $data['list_jeniskegiatan']=$this->jeniskegiatan->getAll();

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
		$this->load->view('jeniskegiatan/view_jeniskegiatan',$data);
        $this->load->view('layout/footer');
	}


    public function view(){
        $_id = $this->input->get('id');
        // $_judul = $this->input->get('id');
        $this->load->model('jeniskegiatan_model','jeniskegiatan'); 
        $data['jk']=$this->jeniskegiatan->findById($_id);
        // $data['ck']=$this->cobakegiatan->getById($_judul);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jeniskegiatan/view',$data);
        $this->load->view('layout/footer');
        //die("judul ".$_judul);
    }

    public function create(){
        $this->load->model('all_model','all');

        $data['judul']='Form Kelola Jenis Kegiatan';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jeniskegiatan/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        $this->load->model("jeniskegiatan_model","jeniskegiatan");
        // $_id = $this->input->get('id');
        // $data['ck']=$this->cobakegiatan->findById($_id);

        $_nama = $this->input->post('nama');
        $_idedit = $this->input->post('idedit');

        // $data_ck[]=$_id;
        $data_jk[]=$_nama;// ? 1

        if(isset($_idedit)){
            //update data lama
            $data_jk[]=$_idedit; // ? 
            $this->jeniskegiatan->update($data_jk);  
        }else{ // save data baru
            // panggi fungsi save di model 
            $this->jeniskegiatan->save($data_jk);
        }
        
        redirect(base_url().'index.php/jeniskegiatan', 'refresh');
    }

    public function edit(){
        $_id = $this->input->get('id');
        $this->load->model("jeniskegiatan_model","jeniskegiatan");
        $jkedit = $this->jeniskegiatan->findById($_id);

        $this->load->model('all_model','all');
		

        $data['judul']='Form Update Jenis Kegiatan';
        $data['jkedit']=$jkedit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jeniskegiatan/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $_id = $this->input->get('id');
        $this->load->model("jeniskegiatan_model","jeniskegiatan");
        $this->jeniskegiatan->delete($_id);
        redirect(base_url().'index.php/jeniskegiatan', 'refresh');
    }

    
} 
?>