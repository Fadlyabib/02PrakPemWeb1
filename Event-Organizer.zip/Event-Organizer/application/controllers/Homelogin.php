<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Homelogin extends CI_Controller {
    public function index(){
        $this->load->model('cobakegiatan_model','cobakegiatan');
        $data['list_cobakegiatan']=$this->cobakegiatan->getAll();

        $this->load->view('home/home',$data);
	}
    public function view(){
        $_id = $this->input->get('id');
        // $_judul = $this->input->get('id');
        $this->load->model('cobakegiatan_model','cobakegiatan');
        $data['ck']=$this->cobakegiatan->findById($_id);
        // $data['ck']=$this->cobakegiatan->getById($_judul);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('cobakegiatan/view',$data);
        $this->load->view('layout/footer');
        //die("judul ".$_judul);
    }
}