<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Users</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/users')?>">Kelola Users</a></li>
            <li class="breadcrumb-item active">View</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-2 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="border-bottom">Data Users</h4>
            <div class="row">
              <div class="col-sm-12">
                <table class='table table-striped'>
                  <tbody>
                    <tr>
                      <td>Username</td>
                      <td>
                        <?=$us->username;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Password</td>
                      <td>
                        <<?=$us->password;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>
                        <?=$us->email;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Created At</td>
                      <td>
                        <?=$us->created_at;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Last Login</td>
                      <td>
                        <?=$us->last_login;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Status</td>
                      <td>
                        <?=$us->status;?>
                      </td>
                    </tr>
                    <tr>
                      <td>Role</td>
                      <td>
                        <?=$us->role;?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div><!-- /.content -->
      </div><!-- /.content-wrapper -->
    </div>
  </div>
</div>