<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) --> 
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Users</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Kelola Users</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4>Data Users</h4>
            <table class='table table-striped'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Created_at</th>
                  <th>Last_login</th>
                  <th>Role</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $nomor = 1;
                foreach($list_users as $row){
                ?>
                <tr>
                  <td><?=$nomor?></td>
                  <td><?= $row->username?></td>
                  <td><?= $row->email?></td>
                  <td><?= $row->created_at?></td>
                  <td><?= $row->last_login?></td>
                  <td><?= $row->role?></td>
                  <td>
                    <a class="btn btn-info" href="users/view?id=<?=$row->id?>">view</a>
                    <a class="btn btn-warning" href="users/edit?id=<?=$row->id?>">Edit</a>
                    <a class="btn btn-danger" href="users/delete?id=<?=$row->id?>"
                    onclick="if(!confirm('Anda Yakin Hapus Users id <?=$row->id?>?')) {return false}">Delete</a>
                  </td>
                </tr>
                <?php
                $nomor++;
                }
                ?>
              </tbody>
            </table>
            <a role="button" class="btn btn-primary" href="<?php echo base_url('index.php/register')?>">Create Users</a>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->