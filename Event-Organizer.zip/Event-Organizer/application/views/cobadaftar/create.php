<!-- Content Wrapper. Contains page content --> 
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Form Processing Daftar</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Create Daftar</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="border-bottom">Form Daftar</h4>
            <div class="row">
              <div class="col-md-8">
                <?php echo form_open('cobadaftar/save')?>
                <!-- <div class="form-group row">
                  <label for="tanggal_daftar" class="col-4 col-form-label">Tanggal Daftar</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-calendar"></i>
                        </div>
                      </div> -->
                      <input id="tanggal_daftar" name="tanggal_daftar" value="<?php $tgl = date('y-m-d'); echo $tgl?>" type="hidden" type="text" 
                      class="form-control">
                    <!-- </div>
                  </div>
                </div> -->
                <!-- <div class="form-group row">
                  <label for="alasan" class="col-4 col-form-label">Alasan</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-card"></i>
                        </div>
                      </div>
                      <input id="alasan" name="alasan" placeholder="Alasan" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div> -->
                <div class="form-group row">
                  <label for="kategori_peserta_id" class="col-4 col-form-label">Kategori Peserta</label> 
                  <div class="col-8">
                    <select id="kategori_peserta_id" name="kategori_peserta_id" class="custom-select" required="required">
                      <option value="">Pilih Kategori Peserta</option>
                      <?php foreach($list_kategori_peserta->result() as $kategori_peserta){ ?>
                      <option value="<?=$kategori_peserta->id?>"><?=$kategori_peserta->nama?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div> 
                <div class="form-group row">
                  <label for="alasan" class="col-4 col-form-label">Alasan Daftar</label> 
                  <div class="col-8">
                    <textarea id="alasan" name="alasan" cols="40" rows="5" required="required"
                    class="form-control"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="users_id" class="col-4 col-form-label">Users</label> 
                  <div class="col-8">
                    <select id="users_id" name="users_id" class="custom-select" required="required">
                      <option value="">Pilih Users</option>
                      <?php foreach($list_users->result() as $users){ ?>
                      <option value="<?= $users->id?>"><?=$users->username?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <!-- <div class="form-group row">
                  <label for="users_id" class="col-4 col-form-label">Alasan</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-card"></i>
                        </div>
                      </div> -->
                      <!-- <input id="users_id" name="users_id" type="hidden" type="text" value="<?php // session_id();?>" class="form-control"> -->
                    <!-- </div>
                  </div>
                </div> -->
                <div class="form-group row">
                  <label for="kegiatan_id" class="col-4 col-form-label">Kegiatan</label> 
                  <div class="col-8">
                    <select id="kegiatan_id" name="kegiatan_id" class="custom-select" required="required">
                      <option value="">Pilih Kegiatan</option>
                      <?php foreach($list_kegiatan->result() as $kegiatan){ ?>
                      <option value="<?=$kegiatan->id?>"><?=$kegiatan->judul?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <!-- <div class="form-group row">
                  <label for="nosertifikat" class="col-4 col-form-label">nosertifikat</label> 
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-bar-chart"></i>
                        </div>
                      </div> -->
                      <input id="nosertifikat" name="nosertifikat" placeholder="nosertifikat" type="hidden" type="text" 
                        class="form-control">
                    <!-- </div>
                  </div>
                </div> -->
                <div class="form-group row">
                  <div class="offset-4 col-8">
                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
                <?php echo form_close()?>
              </div>
              <div class="col-md-4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->