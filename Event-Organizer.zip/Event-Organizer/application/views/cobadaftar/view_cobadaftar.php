<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) --> 
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Daftar</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Kelola Daftar</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4>Data Daftar</h4>
            <table class='table table-striped'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal Daftar</th>
                  <th>Alasan</th>
                  <th>Users id</th>
                  <th>Kegiatan id</th>
                  <th>Kategori Peserta id</th>
                  <th>No Sertifikat</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $nomor = 1;
                foreach($list_cobadaftar as $row){
                ?>
                <tr>
                  <td>
                    <?=$nomor?></td>
                  <td>
                    <?=$row->tanggal_daftar;?>
                  </td>
                  <td>
                    <?=$row->alasan;?>
                  </td>
                  <td>
                    <?=$row->users_id;?>
                  </td>
                  <td>
                    <?=$row->kegiatan_id;?>
                  </td>
                  <td>
                    <?=$row->kategori_peserta_id;?>
                  </td>
                  <td>
                    <?=$row->nosertifikat;?>
                  </td>
                  <td>
                    <a class="btn btn-info" href="cobadaftar/view?id=<?=$row->tanggal_daftar?>">view</a>
                    <?php 
                    if($this->session->userdata('role')=='administrator'){
                    ?>
                    <a class="btn btn-warning" href="cobadaftar/edit?id=<?=$row->tanggal_daftar?>">Edit</a>
                    <a class="btn btn-danger" href="cobadaftar/delete?id=<?=$row->tanggal_daftar?>"
                    onclick="if(!confirm('Anda Yakin Hapus cobadaftar Tanggal Daftar <?=$row->tanggal_daftar?>?')) {return false}">Delete</a>
                    <?php 
                    }
                    ?>
                  </td>
                </tr>
                <?php
                $nomor++;
                }
                ?>
              </tbody>
            </table>
            <a role="button" class="btn btn-primary" href="<?php echo base_url('index.php/cobadaftar/create')?>">Create Daftar</a>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->  