<div class="content-wrapper">
  <!-- Content Header (Page header) --> 
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>
            <?=$judul?>
          </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/cobadaftar')?>">Kelola Daftar</a></li>
            <li class="breadcrumb-item active">Update</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">
          <?=$judul?>
        </h3>
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <?php
        $hidden = ['idedit'=>$cdedit->tanggal_daftar];
        ?>
        <?php echo form_open('cobadaftar/save','',$hidden)?>
        <div class="form-group row">
          <label for="tanggal_daftar" class="col-4 col-form-label">tanggal_daftar</label> 
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-500px"></i>
                </div>
              </div>
              <input id="tanggal_daftar" name="tanggal_daftar" value="<?=$cdedit->tanggal_daftar?>" type="text" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="alasan" class="col-4 col-form-label">alasan Lengkap</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-address-book"></i>
                </div>
              </div>
              <input id="alasan" name="alasan" value="<?=$cdedit->alasan?>" type="text" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
            <label for="users_id" class="col-4 col-form-label">Users</label> 
            <div class="col-8">
                <select id="users_id" name="users_id" class="custom-select" required="required">
                    <option value=""><?=$cdedit->users_id?></option>
                    <?php foreach($list_users->result() as $users){ ?>
                    <option value="<?=$users->id?>"><?=$users->username?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="kegiatan_id" class="col-4 col-form-label">Kegiatan</label> 
            <div class="col-8">
                <select id="kegiatan_id" name="kegiatan_id" class="custom-select" required="required">
                    <option value=""><?=$cdedit->kegiatan_id?></option>
                    <?php foreach($list_kegiatan->result() as $kegiatan){ ?>
                    <option value="<?=$kegiatan->id?>"><?=$kegiatan->judul?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="kategori_peserta_id" class="col-4 col-form-label">Kategori Peserta</label> 
            <div class="col-8">
                <select id="kategori_peserta_id" name="kategori_peserta_id" class="custom-select" required="required">
                    <option value=""><?=$cdedit->kategori_peserta_id?></option>
                    <?php foreach($list_kategori_peserta->result() as $kategori_peserta){ ?>
                    <option value="<?=$kategori_peserta->id?>"><?=$kategori_peserta->nama?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
          <label for="nosertifikat" class="col-4 col-form-label">nosertifikat</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-adn"></i>
                </div>
              </div>
              <input id="nosertifikat" name="nosertifikat" value="<?=$cdedit->nosertifikat?>" type="text" class="form-control">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <div class="offset-4 col-8">
            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
        <?php echo form_close()?>
      </div>
      <!-- /.card-body -->
      <div class="card-footer">
      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->
  </section>
  <!-- /.content -->
</div>