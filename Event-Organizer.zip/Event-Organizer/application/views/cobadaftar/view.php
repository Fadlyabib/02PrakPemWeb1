<!-- Content Wrapper. Contains page content --> 
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Daftar</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/cobadaftar')?>">Kelola Daftar</a></li>
            <li class="breadcrumb-item active">view</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-2 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
          <h4 class="border-bottom">Data Daftar</h4>
            <div class="row">
              <div class="col-sm-12">
                <table class='table table-striped'>
                  <tbody>
                    <tr>
                      <td>
                        tanggal_daftar
                      </td>
                      <td>
                        <?=$cd->tanggal_daftar;?>
                      </td>
                    </tr>
                    <tr>
                      <td>alasan</td>
                      <td><?=$cd->alasan;?></td>
                    </tr>
                    <tr>
                      <td>
                        users_id
                      </td>
                      <td>
                        <?=$cd->users_id;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Tempat Lahir
                      </td>
                      <td>
                        <?=$cd->kegiatan_id;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Tanggal Lahir
                      </td>
                      <td>
                        <?=$cd->kategori_peserta_id;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        nosertifikat
                      </td>
                      <td>
                        <?=$cd->nosertifikat;?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->