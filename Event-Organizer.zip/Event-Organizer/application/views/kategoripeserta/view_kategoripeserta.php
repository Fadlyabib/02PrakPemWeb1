<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) --> 
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Kategori Peserta</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Kelola Kategori Peserta</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content --> 
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4>Data Kategori Peserta</h4>
            <table class='table table-striped'>
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Kategori Peserta</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $nomor = 1;
                foreach($list_kategoripeserta as $row){
                ?>
                <tr>
                  <td>
                    <?=$nomor?></td>
                  <td>
                    <?=$row->nama;?>
                  </td>
                  <td>
                    <a class="btn btn-info" href="kategoripeserta/view?id=<?=$row->id?>">view</a>
                    <a class="btn btn-warning" href="kategoripeserta/edit?id=<?=$row->id?>">Edit</a>
                    <a class="btn btn-danger" href="kategoripeserta/delete?id=<?=$row->id?>"
                    onclick="if(!confirm('Anda Yakin Hapus Kegiatan id <?=$row->id?>?')) {return false}">Delete</a>
                  </td>
                </tr>
                <?php
                $nomor++;
                }
                ?>
              </tbody>
            </table>
            <a role="button" class="btn btn-primary" href="<?php echo base_url('index.php/kategoripeserta/create')?>">Create Daftar</a>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->  