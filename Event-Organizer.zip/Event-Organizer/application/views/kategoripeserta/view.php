<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Kategori Peserta</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/jeniskegiatan')?>">Kelola Kategori
                Peserta</a></li>
            <li class="breadcrumb-item active">View</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-2 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="border-bottom">Data Kategori Peserta</h4>
            <div class="row">
              <div class="col-sm-12">
                <table class='table table-striped'>
                  <tbody>
                    <tr>
                      <td>
                        Nama Kategori Peserta
                      </td>
                      <td>
                        <?=$kp->nama;?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- /.content -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-wrapper -->