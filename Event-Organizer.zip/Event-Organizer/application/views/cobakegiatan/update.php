<div class="content-wrapper">
  <!-- Content Header (Page header) --> 
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>
            <?=$judul?>
          </h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/cobakegiatan')?>">Kelola Kegiatan</a></li>
            <li class="breadcrumb-item active">Update</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">
          <?=$judul?>
        </h3>
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <?php
        $hidden = ['idedit'=>$ckedit->id]; 
        ?>
        <?php echo form_open('cobakegiatan/save','',$hidden)?>
        <div class="form-group row">
          <label for="judul" class="col-4 col-form-label">Judul</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-500px"></i>
                </div>
              </div>
              <input id="judul" name="judul" value="<?=$ckedit->judul?>" type="text" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="kapasitas" class="col-4 col-form-label">Kapasitas</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-address-book"></i>
                </div>
              </div>
              <input id="kapasitas" name="kapasitas" value="<?=$ckedit->kapasitas?>" type="number" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="harga_tiket" class="col-4 col-form-label">Harga Tiket</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-adn"></i>
                </div>
              </div>
              <input id="harga_tiket" name="harga_tiket" value="<?=$ckedit->harga_tiket?>" type="number" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="tanggal" class="col-4 col-form-label">Tanggal</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-500px"></i>
                </div>
              </div>
              <input id="tanggal" name="tanggal" value="<?=$ckedit->tanggal?>" type="date" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="narasumber" class="col-4 col-form-label">Narasumber</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-adn"></i>
                </div>
              </div>
              <input id="narasumber" name="narasumber" value="<?=$ckedit->narasumber?>" type="text" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="tempat" class="col-4 col-form-label">Tempat</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-adn"></i>
                </div>
              </div>
              <input id="tempat" name="tempat" value="<?=$ckedit->tempat?>" type="text" class="form-control"required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
          <label for="pic" class="col-4 col-form-label">PIC</label>
          <div class="col-8">
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fa fa-adn"></i>
                </div>
              </div>
              <input id="pic" name="pic" value="<?=$ckedit->pic?>" type="text" class="form-control" required="required">
            </div>
          </div>
        </div>
        <div class="form-group row">
            <label for="jenis_id" class="col-4 col-form-label">Jenis Kegiatan</label> 
            <div class="col-8">
                <select id="jenis_id" name="jenis_id" class="custom-select" required="required">
                    <option value=""><?=$ckedit->jenis_id?></option>
                    <?php foreach($list_jenis_kegiatan->result() as $jenis_kegiatan){ ?>
                    <option value="<?=$jenis_kegiatan->id?>"><?=$jenis_kegiatan->id?>-<?=$jenis_kegiatan->nama?></option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="form-group row">
          <div class="offset-4 col-8">
            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
        <?php echo form_close()?>
      </div>
      <!-- /.card-body -->
      <div class="card-footer">
      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->
  </section>
  <!-- /.content -->
</div>