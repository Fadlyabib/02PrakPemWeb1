<!-- Content Wrapper. Contains page content --> 
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Kegiatan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/cobakegiatan')?>">Kelola Kegiatan</a></li>
            <li class="breadcrumb-item active">View</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-2 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
          <h4 class="border-bottom">Data Kegiatan</h4>
            <div class="row">
              <div class="col-sm-9">
                <table class='table table-striped'>
                  <tbody>
                    <tr>
                      <td>
                        Judul
                      </td>
                      <td>
                        <?=$ck->judul;?>
                      </td>
                    </tr>
                    <tr>
                      <td>kapasitas</td>
                      <td><?=$ck->kapasitas;?></td>
                    </tr>
                    <tr>
                      <td>
                        Harga Tiket
                      </td>
                      <td>
                        <?=$ck->harga_tiket;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Tanggal
                      </td>
                      <td>
                        <?=$ck->tanggal;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Narasumber
                      </td>
                      <td>
                        <?=$ck->narasumber;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Tempat
                      </td>
                      <td>
                        <?=$ck->tempat;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        PIC
                      </td>
                      <td>
                        <?=$ck->pic;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Jenis id
                      </td>
                      <td>
                        <?=$ck->jenis_id;?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="col-sm-3">
                <?php 
                $filegambar = base_url('/uploads/'.$ck->foto_flyer);
                // echo $filegambar;
                $array = get_headers($filegambar);
                $string = $array[0];
                if(strpos($string,"200")){
                  // echo "url excist";
                  echo '<img width="70%" src="'.$filegambar.'" alt="foto_flyer" class="img-tumbnail"/>';
                }else{
                  // echo "url does not excist";
                  echo '<img src="'.base_url('/uploads/noimage.png').'" alt="foto_flyer" class="mx-auto d-block"/>';
                }
                ?>
                <br>
                Nama File: <?=$ck->foto_flyer?>
                <br>
                <?php
                  echo form_open_multipart('cobakegiatan/upload');
                ?>
                  <input type="hidden" name="id" value="<?=$ck->id?>">
                  <input type="file" name="foto_flyerck" size="20"/>
                  <br>
                  <input type="submit" class="btn btn-success" value="upload"/>
                <?php echo form_close()?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->