<!-- Content Wrapper. Contains page content --> 
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Form Processing Kegiatan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/dashboard')?>">Home</a></li>
            <li class="breadcrumb-item active">Create Kegiatan</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <div class="container-fluid">
    <div class="row ml-1 mr-1">
      <div class="col-md-12 shadow-sm p-3 bg-white rounded bg-light">
        <div class="row">
          <div class="col-sm-12">
            <h4 class="border-bottom">Form Kegiatan</h4>
            <div class="row">
              <div class="col-md-8">
                <?php echo form_open('cobakegiatan/save')?>
                <div class="form-group row">
                  <label for="judul" class="col-4 col-form-label">Judul</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-calendar"></i>
                        </div>
                      </div>
                      <input id="judul" name="judul" placeholder="Judul" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="kapasitas" class="col-4 col-form-label">Kapasitas</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-card"></i>
                        </div>
                      </div>
                      <input id="kapasitas" name="kapasitas" placeholder="Kapasitas" type="number" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="harga_tiket" class="col-4 col-form-label">Harga Tiket</label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-address-card"></i>
                        </div>
                      </div>
                      <input id="harga_tiket" name="harga_tiket" placeholder="Harga Tiket" type="number" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <!-- <div class="form-group row"> -->
                  <!-- <label for="tanggal" class="col-4 col-form-label"></label>
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-calendar"></i>
                        </div>
                      </div> -->
                      <input id="tanggal" name="tanggal" placeholder="tanggal" value="<?php $tgl = date('y-m-d'); echo $tgl?>" type="hidden" type="text" required="required"
                        class="form-control">
                    <!-- </div>
                  </div> -->
                <!-- </div> -->
                <div class="form-group row">
                  <label for="narasumber" class="col-4 col-form-label">Narasumber</label> 
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-bar-chart"></i>
                        </div>
                      </div>
                      <input id="narasumber" name="narasumber" placeholder="Narasumber" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="tempat" class="col-4 col-form-label">Tempat</label> 
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-bar-chart"></i>
                        </div>
                      </div>
                      <input id="tempat" name="tempat" placeholder="Tempat" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="pic" class="col-4 col-form-label">PIC</label> 
                  <div class="col-8">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa fa-bar-chart"></i>
                        </div>
                      </div>
                      <input id="pic" name="pic" placeholder="PIC" type="text" required="required"
                        class="form-control">
                    </div>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="jenis_id" class="col-4 col-form-label">Jenis Kegiatan</label> 
                  <div class="col-8">
                    <select id="jenis_id" name="jenis_id" class="custom-select" required="required">
                      <option value="">Pilih Jenis Kegiatan</option>
                      <?php foreach($list_jenis_kegiatan->result() as $jenis_kegiatan){ ?>
                      <option value="<?=$jenis_kegiatan->id?>"><?=$jenis_kegiatan->nama?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div> 
                <div class="form-group row">
                  <div class="offset-4 col-8">
                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
                <?php echo form_close()?>
              </div>
              <div class="col-md-4">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><!-- /.container-fluid -->
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->